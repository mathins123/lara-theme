<x-app-layout>
    <section class="px-8 md:px-12">
        <div class="py-8 md:py-12">
            <div class="container px-4 md:px-16 mx-auto">
                <div class="flex flex-wrap">
                    <div class="w-full md:w-1/2 px-4">
                        <img src="/image/Group-72.png" class="mx-auto"/>
                    </div>
                    <div class="w-full md:w-1/2 px-4 md:pl-16">
                        <h1 class="my-6 text-title1">
                            {{ __('contact.title_1') }}
                        </h1>
                        <p class="my-3">
                            {{ __('contact.title_1_content') }}
                        </p>
                        <form method="POST" action="">
                            @csrf
                            <div>
                                <x-label for="name" value="{{ __('contact.form_name') }}" />
                                <x-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
                                <x-input-error for="name" class="mt-2" />
                            </div>
                            <div class="mt-3">
                                <x-label for="email" value="{{ __('contact.form_email') }}" />
                                <x-input id="email" class="block mt-1 w-full" type="text" name="email" :value="old('email')" required autofocus autocomplete="email" />
                                <x-input-error for="email" class="mt-2" />
                            </div>
                            <div class="mt-3">
                                <x-label for="message" value="{{ __('contact.form_message') }}" />
                                <x-textarea id="message" class="block mt-1 w-full" name="message" :value="old('message')" required autofocus autocomplete="message"></x-textarea>
                                <x-input-error for="message" class="mt-2" />
                            </div>
                            
                            <button type="submit" class="mt-3 bg-primary hover:bg-blue-500 text-white transition duration-500 px-6 py-3 rounded-sm">
                                {{__("contact.form_submit")}}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="px-8 md:px-12">
        <div class="py-8 md:py-12">
            <div class="container px-4 md:px-16 mx-auto">
                <h2 class="text-title2 text-center">
                    {{__("contact.title_2")}}
                </h2>
                <p class="mb-8">
                    {{__("contact.title_2_content")}}
                </p>
                <div class="grid grid-cols-3 gap-0 md:gap-16">
                    <div class="col-span-3 md:col-span-1">
                        <h3 class="text-headline border-b-2 border-secondary my-4 py-2">
                            {{__("contact.title_2_1")}}
                        </h3>
                        <p class="my-3"> +34 620 18 79 86 </p>
                        <p class="my-3"> +34 915 612 921 </p>
                    </div>
                    <div class="col-span-3 md:col-span-1">
                        <h3 class="text-headline border-b-2 border-secondary my-4 py-2">
                            {{__("contact.title_2_2")}}
                        </h3>
                        <p class="my-3"> info@resify.es </p>
                    </div>
                    <div class="col-span-3 md:col-span-1">
                        <h3 class="text-headline border-b-2 border-secondary my-4 py-2">
                            {{__("contact.title_2_3")}}
                        </h3>
                        <p class="my-3"> 
                            Avenida Comandante Franco Número 4 Bis, 28016, Madrid.    
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="px-8 md:px-12 border-t border-gray-200">
        <div class="py-8 md:py-12">
            <div class="container px-4 md:px-16 mx-auto">
                <h2 class="text-title2 text-center">
                    {{__("contact.title_3")}}
                </h2>
                <p class="mb-8">
                    {{__("contact.title_3_content")}}
                </p>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
                    <div class="col-span-1 text-center p-4">
                        <img class="w-32 my-3 mx-auto" src="/image/Group-39761.svg"/>
                        <p class="my-3">
                            {{__("contact.title_3_1")}}    
                        </p>
                    </div>
                    <div class="col-span-1 text-center p-4">
                        <img class="w-32 my-3 mx-auto" src="/image/Group-39762.svg"/>
                        <p class="my-3">
                            {{__("contact.title_3_2")}}    
                        </p>
                    </div>
                    <div class="col-span-1 text-center p-4">
                        <img class="w-32 my-3 mx-auto" src="/image/Group-39763.svg"/>
                        <p class="my-3">
                            {{__("contact.title_3_3")}}    
                        </p>
                    </div>
                    <div class="col-span-1 text-center p-4">
                        <img class="w-32 my-3 mx-auto" src="/image/Group-39764.svg"/>
                        <p class="my-3">
                            {{__("contact.title_3_4")}}    
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-app-layout>