<x-app-layout>
    <section class="px-8 overflow-hidden bg-gray-100 md:px-12">
        <div class="py-8 md:py-12">
            <div class="container px-4 mx-auto md:px-16">
                <h2 class="my-3 text-headline">
                    {{__("legal.title_0")}}
                </h2>
                <p>
                    {{__("legal.title_0_content_1")}}<br/><br/>
                </p>
                <p>
                    {{__("legal.title_0_content_2")}}
                </p>

                <h2 class="my-3 text-headline">
                    {{__("legal.title_1")}}
                </h2>
                <p>
                    {{__("legal.title_1_content_1")}}
                </p>
                <p>
                    {{__("legal.title_1_content_2")}}
                </p>
                <p>
                    {{__("legal.title_1_content_3")}}
                </p>
                <p>
                    {{__("legal.title_1_content_4")}}
                </p>
                <p>
                    {{__("legal.title_1_content_5")}}
                </p>
                <p>
                    {{__("legal.title_1_content_6")}}
                </p>
                <p>
                    {{__("legal.title_1_content_7")}}
                </p>

                <h2 class="my-3 mt-8 text-headline">
                    {{__("legal.title_2")}}
                </h2>
                    @for ($i=1; $i<=4; $i++)
                        <p>{{__("legal.title_2_content_$i")}}<br/><br/></p>
                    @endfor

                <h2 class="my-3 text-headline">
                    {{__("legal.title_3")}}
                </h2>
                <p>
                    {{__("legal.title_3_content_1")}}<br/><br/>
                </p>
                <p>
                    {{__("legal.title_3_content_2")}}<br/><br/>
                </p>
                <p>
                    {{__("legal.title_3_content_3")}}<br/><br/>
                </p>

                <h2 class="my-3 text-headline">
                    {{__("legal.title_4")}}
                </h2>
                <p>
                    {{__("legal.title_4_content_1")}}<br/><br/>
                </p>
                <p>
                    {{__("legal.title_4_content_2")}}<br/><br/>
                </p>

                <h2 class="my-3 text-headline">
                    {{__("legal.title_5")}}
                </h2>
                <p>
                    {{__("legal.title_5_content_1")}}<br/><br/>
                </p>

                <h2 class="my-3 text-headline">
                    {{__("legal.title_6")}}
                </h2>
                <p>
                    {{__("legal.title_6_content_1")}}<br/><br/>
                </p>

                <h2 class="my-3 text-headline">
                    {{__("legal.title_7")}}
                </h2>
                <p>
                    {{__("legal.title_7_content_1")}}<br/><br/>
                </p>
                <p>
                    {{__("legal.title_7_content_2")}}<a href="http://www.protectionreport.com/" style="color:blue">{{__("legal.title_7_content_3")}}</a>{{__("legal.title_7_content_4")}}<br/><br/>
                </p>
            </div>
        </div>
    </section>
</x-app-layout>
