<div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('company')): ?>
        <h3 class="mb-5">
            <a class="text-headline" href="<?php echo e(route("employee.notification")); ?>">
                Employee List
            </a>
            <i class="fa fa-angle-double-right mx-1"></i>
            <?php echo e($user->name); ?>

        </h3>
    <?php endif; ?>

    <h1 class="text-title2"> <?php echo e(__("menu.notification")); ?> </h1>

    <div x-data="{ activeTab:  0 }">
        <div class="mt-5 font-medium text-center text-gray-500 border-b bg-gray-100 border-gray-200 dark:text-gray-400 dark:border-gray-700">
            <ul class="flex flex-wrap -mb-px">
                <li class="mr-2">
                    <a href="#" @click="activeTab = 0" class="inline-block p-4 border-b-2 rounded-t-lg"
                        :class="{' hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300 border-transparent' :  activeTab !== 0, 'text-blue-600 border-blue-600 active dark:text-blue-500 dark:border-blue-500' :  activeTab === 0 }">
                        <?php echo e(__("notification.menu_1")); ?>

                    </a>
                </li>
                <li>
                    <a href="#" @click="activeTab = 1" class="inline-block p-4 border-b-2 rounded-t-lg"
                        :class="{ 'hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300 border-transparent' :  activeTab !== 1, 'text-blue-600 border-blue-600 active dark:text-blue-500 dark:border-blue-500' :  activeTab === 1 }">
                        <?php echo e(__("notification.menu_2")); ?>

                    </a>
                </li>
            </ul>
        </div>

        <div>
            <div id="history" x-show.transition.in.opacity.duration.600="activeTab === 0">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="notification-<?php echo e($notification->id); ?>-collapse" data-accordion="collapse"
                        class="my-9 border rounded-lg p-5 relative">
                        <button wire:click="deleteNotification(<?php echo e($notification->id); ?>)" class="absolute top-3 right-3">
                            <i class="fa fa-trash text-red-500"></i>
                        </button>
                        <h2 id="notification-<?php echo e($notification->id); ?>-collapse-heading-1" class="mr-5">
                            <button type="button" class="flex justify-between w-full bg-white text-left"
                                data-accordion-target="#notification-<?php echo e($notification->id); ?>-collapse-body-1" 
                                aria-expanded="false" aria-controls="notification-<?php echo e($notification->id); ?>-collapse-body-1">
                                <span><?php echo e($notification->title()); ?></span>
                                <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                            </button>
                        </h2>
                        <div id="notification-<?php echo e($notification->id); ?>-collapse-body-1" class="my-5 whitespace-pre-wrap hidden" aria-labelledby="cetification-requirement-collapse-heading-1">
                            <?php echo $notification->details(); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="setting" x-show.transition.in.opacity.duration.600="activeTab === 1">
                <div class="my-5">
                    <input id="email-setting" type="checkbox" class="hidden" wire:model.lazy="enabledEmailNotify"/>
                    <label for="email-setting" class="flex">
                        <img class="h-5 mr-3" src="<?php echo e($enabledEmailNotify ? asset('image/toggle_on.png') : asset('image/toggle_off.png')); ?>"/>
                        <?php echo e(__('notification.option_1')); ?>

                    </label>
                </div>
                <div class="my-5">
                    <input id="text-setting" type="checkbox" class="hidden" wire:model.lazy="enabledTextNotify"/>
                    <label for="text-setting" class="flex">
                        <img class="h-5 mr-3" src="<?php echo e($enabledTextNotify ? asset('image/toggle_on.png') : asset('image/toggle_off.png')); ?>"/>
                        <?php echo e(__('notification.option_2')); ?>

                    </label>
                </div>
                <div class="mt-8">
                    <button class="bg-white hover:bg-primary border border-primary rounded-lg text-primary hover:text-white px-5 py-3">
                        <?php echo e(__("notification.button_cancel")); ?>

                    </button>
                    <button class="bg-primary hover:bg-white border border-primary rounded-lg text-white hover:text-primary px-5 py-3 ml-5"
                        wire:click="saveNotificationSetting()">
                        <?php echo e(__("notification.button_save")); ?>

                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Work\Laravel\resify\resources\views/livewire/profile/notification.blade.php ENDPATH**/ ?>