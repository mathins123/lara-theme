@props([
    'name' => '',
    'label' => '',
    'required' => false
])

@if ($label == '')
    @php
        //remove underscores from name
        $label = str_replace('_', ' ', $name);
        //detect subsequent letters starting with a capital
        $label = preg_split('/(?=[A-Z])/', $label);
        //display capital words with a space
        $label = implode(' ', $label);
        //uppercase first letter and lower the rest of a word
        $label = ucwords(strtolower($label));
    @endphp
@endif
<div wire:ignore class="mt-5">
    @if ($label !='none')
        <label for="{{ $name }}" class="block text-sm font-medium leading-5 text-gray-700 dark:text-gray-200">
            {{ $label }} 
            @if ($required != '') 
                <span class="text-red-600">*</span>
            @endif
        </label>
    @endif
    <textarea
        x-data
        x-init="ClassicEditor
            .create( document.querySelector( '.ck-editor' ),{
                simpleUpload: {
                    uploadUrl: '{{ route('editor.upload') }}',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                }
            })
            .then( editor => {
                editor.model.document.on('change:data', () => {
                    @this.set('{{ $name }}', editor.getData());
                })
            } )
            .catch( err => {
                console.error( err );
            } );
        "
        class="ck-editor"
        x-ref="item"
        {{ $attributes }}
    >
        {{ $slot }}
    </textarea>
</div>
@error($name)
    <p class="text-sm text-red-600">{{ $message }}</p>
@enderror