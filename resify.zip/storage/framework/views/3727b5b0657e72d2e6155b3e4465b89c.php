<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id', 'maxWidth', 'formAction' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'maxWidth', 'formAction' => false]); ?>
<?php foreach (array_filter((['id', 'maxWidth', 'formAction' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="z-50 bg-white border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 ">
    <?php if($formAction): ?>
        <form wire:submit.prevent="<?php echo e($formAction); ?>">
            <?php echo csrf_field(); ?>
    <?php endif; ?>
            <div class="p-4 sm:px-6 sm:py-4 border-b border-gray-600">
                <?php if(isset($title)): ?>
                    <h3 class="text-lg leading-6 font-medium">
                        <?php echo e($title); ?>

                    </h3>
                <?php endif; ?>
            </div>
            <div class="px-4 sm:p-6">
                <div class="space-y-6">
                    <?php if(isset($content)): ?>
                        <?php echo e($content); ?>

                    <?php endif; ?>
                </div>
            </div>
            <?php if(isset($buttons)): ?>
                <div class="px-4 pb-5">
                    <div class="text-right">
                        
                            <?php echo e($buttons); ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php if($formAction): ?>
        </form>
    <?php endif; ?>
</div><?php /**PATH D:\Work\Laravel\resify\resources\views/components/modal.blade.php ENDPATH**/ ?>