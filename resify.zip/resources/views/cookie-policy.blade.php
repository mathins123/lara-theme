<x-app-layout>
    <section class="px-8 md:px-12 bg-gray-100 overflow-hidden">
        <div class="py-8 md:py-12">
            <div class="container px-4 md:px-16 mx-auto">
                <p>
                    {{__("cookie_policy.intro")}}
                </p>
                @php
                    $cnts = [1, 6, 7, 3, 2];
                @endphp

                @foreach ($cnts as $cnt)
                    <h2 class="text-headline my-3 mt-8">
                        {{__("cookie_policy.title_$loop->iteration")}}
                    </h2>
                    @for($i = 1; $i <= $cnt; $i++)
                        <p class="my-3">
                            {!!__("cookie_policy.title_" . $loop->iteration . "_content_" . $i)!!}
                        </p>    
                    @endfor
                @endforeach
            </div>
        </div>
    </section>
</x-app-layout>