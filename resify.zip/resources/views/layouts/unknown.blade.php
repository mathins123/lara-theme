<html>
    <body>
        <div class="text-orange-400"></div>
        <div class="text-yellow-400"></div>
        <div class="text-green-400"></div>

    </body>
</html>