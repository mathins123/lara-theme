<x-app-layout>
    <section class="pr-8 md:pr-12 bg-white">
        <div class="pr-4 md:pr-8">
            <div class="flex flex-wrap" style="min-height: calc(100vh - 80px)">
                <div class="w-0 md:w-1/3 bg-left bg-no-repeat"
                    style="background-image: url('/image/login_bg.jpg')">
                </div>
                <div class="w-full md:w-2/3 px-8 md:px-16 py-16">
                    <h1 class="my-6 text-title1">
                        {{ __('login.title_1') }}
                    </h1>
                    <p class="my-5 border-b border-dashed border-gray-500 text-primary p-1">
                        {{ __('login.title_2') }}
                    </p>

                    <div class="w-3/5">
                        <x-validation-errors class="mb-4" />

                        @if (session('status'))
                            <div class="mb-4 font-medium text-sm text-green-600">
                                {{ session('status') }}
                            </div>
                        @endif
                        <form method="POST" action="{{ route('login') }}">
                            @csrf
                            <div class="mt-3">
                                <x-label for="email" value="{{ __('login.form_email') }}" />
                                <x-input id="email" class="block mt-1 w-full" type="text" name="email" :value="old('email')" required autofocus autocomplete="email" />
                            </div>
                            <div class="mt-4">
                                <x-label for="password" value="{{ __('login.form_password') }}" />
                                <x-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="current-password" />
                            </div>
                
                            <div class="mt-4 flex justify-between">
                                <label for="remember_me" class="flex items-center">
                                    <x-checkbox id="remember_me" name="remember" />
                                    <span class="ml-2 text-sm text-gray-600">
                                        {{ __("login.form_remember") }}
                                    </span>
                                </label>

                                @if (Route::has('password.request'))
                                    <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="{{ route('password.request') }}">
                                        {{ __("login.form_forgot") }}
                                    </a>
                                @endif
                            </div>
                
                            <div class="mt-8">
                                <button type="submit" class="w-full py-2 bg-primary hover:bg-blue-500 rounded-lg text-white text-center transition duration-500">
                                    {{ __("login.form_submit") }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-app-layout>