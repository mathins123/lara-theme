<?php
return  [
    "login" => "登录",
    "register" => "注册",
    "about_us" => "我们是谁",
    "our_service" => "我们的服务",
    "blog" => "博客",
    "contact" => "联系人",
    "manage_account" => "管理账户",
    "my_profile" => "我的个人资料",
    "log_out" => "注销",
    "my_procedure" => "我的程序",
    "my_profile" => "我的个人资料",
    "payment" => "付款和账单",
    "notification" => "通知",
];