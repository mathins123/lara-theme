<?php
return [
    "title_1" => "Accede a tu cuenta de Resify",
    "title_2" => "¡Hola de nuevo!",
    "form_email" => "Email",
    "form_password" => "Contraseña",
    "form_remember" => "Recordar usuario",
    "form_forgot" => "¿Ha olvidado su contraseña?",
    "form_submit" => "Acceder"
];