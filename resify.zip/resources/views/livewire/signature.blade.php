<x-modal formAction="addSignature">
    <x-slot name="title">
        Add Signature on document
    </x-slot>

    <x-slot name="content">
        <div x-init="[initSignature()]"
            x-data="modalSignature({ 
                signatureImage: @entangle('signature')
            })">
            <canvas x-ref="canvas" height="250" width="400" class="border-2 border-dashed border-gray-500 bg-white"></canvas>
            <div class="px-5 mt-5">
                <div class="text-right">
                    <button type="button" class="px-3 py-2 text-sm tracking-wide text-white capitalize transition-colors duration-200 transform bg-blue-500 rounded-md dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:bg-blue-700 hover:bg-blue-600 focus:outline-none focus:bg-blue-500 focus:ring focus:ring-blue-300 focus:ring-opacity-50"
                        @click="clearCanvas();">
                        Clear
                    </button>
                    <x-button>
                        Save
                    </x-button>
                </div>
            </div>
        </div>
    </x-slot>
</x-modal>
