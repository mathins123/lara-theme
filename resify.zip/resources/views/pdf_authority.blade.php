<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>
        <link rel="stylesheet" href="{{ public_path('print.css') }}">
        {{-- <link rel="stylesheet" href="/print.css"> --}}
    </head>
    <body class="text-small print">
        <div class="min-h-screen bg-white relative">
            <div class="px-5 py-1">
                <p>
                    <span class="font-bold">D./Dña.</span> {{$procedureForm->first_name}} {{$procedureForm->middle_name}} {{$procedureForm->last_name}}, con NIE nº {{$procedureForm->dni}} y Pasaporte nº {{$procedureForm->passport}} con domicilio en {{$procedureForm->address_spain}}
                </p>
                <h1 class="my-5 text-center text-3xl font-extrabold underline">
                    AUTORIZA
                </h1>

                <p>
                    <span class="font-bold">A D. GONZALO ASTOLFI ESPINOSA</span>, mayor de edad, abogado colegiado nº 132443 del Colegio de Abogados de Madrid y provisto de DNI nº 79043367-A, con domicilio en Avenida Alberto Alcocer nº 41, 28016, Madrid, pudiendo ser notificado por vía telemática a info@resify.es, para que en mi nombre y ante este organismo pueda presentar la solicitud de {{$certification}}, recoger las resoluciones favorables y cualesquiera otras notificaciones o requerimientos emitidos por la Administración Pública a mi favor, así como contestar a los mismos y aportar cualquier documentación adicional que pueda ser necesaria
                </p>
                
                <p class="my-5">
                    Y, para que surta todos los efectos oportunos, firmamos la presente en {{$procedureForm->city}} a {{date("Y/m/d")}}
                </p>

                <span class="mt-5">
                    {{$procedureForm->first_name}} {{$procedureForm->middle_name}} {{$procedureForm->last_name}}
                </span>
            </div>
        </div>
    </body>
</html>
