<x-app-layout>
    <section class="px-8 md:px-12 py-8 md:py-12 bg-gray-100">
        <div class="container px-4 mx-auto">
            <div>
                <h1 class="text-title1 text-center">
                    {{__("our_service.title_2")}}
                </h1>
                <h1 class="text-title1 text-center">
                    {{__("our_service.title_2_")}}
                </h1>
            </div>
            <div class="flex flex-wrap -mx-4 py-8">
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/shutterstock_705449866-11.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            {{__("dashboard.student")}}
                        </h3>
                        <p>
                            {!! __("dashboard.student_intro_1") !!}
                        </p>
                        <p>
                            {!!__("dashboard.student_intro_2")!!}
                        </p>
                        <p>
                            {!!__("dashboard.student_intro_3")!!}
                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="{{route("register.user", "student")}}">
                            {{__("dashboard.student_start")}}
                        </a>
                    </div>
                </div>
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/shutterstock_368581874-1.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            {{__("dashboard.individual")}}
                        </h3>
                        <p>
                            {!!__("dashboard.individual_intro_1")!!}
                        </p>
                        <p>
                            {!!__("dashboard.individual_intro_2")!!}
                        </p>
                        <p>
                            {!!__("dashboard.individual_intro_3")!!}
                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="{{route("register.user", "individual")}}">
                            {{__("dashboard.individual_start")}}
                        </a>
                    </div>
                </div>
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/team-meeting-online-conference-call-laptop-1.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            {{__("dashboard.company")}}
                        </h3>
                        <p>
                            {!!__("dashboard.company_intro")!!}
                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="{{route("register.user", "company")}}">
                            {{__("dashboard.company_start")}}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-app-layout>