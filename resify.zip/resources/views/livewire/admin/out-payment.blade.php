<x-modal formAction="createQuestionnaire">
    <x-slot name="title">
        Create Outside Payment Details
    </x-slot>

    <x-slot name="content">
        <div>
            <x-label for="certificate" value="Certification Type" />
            <x-simple-select
                wire:model.lazy="certificate"
                name="certificate"
                id="certificate"
                :options="$certificationTypes"
                value-field='id'
                text-field='display_name'
                placeholder="Select Certification Type"
                search-input-placeholder="Select Certification Type"
                :searchable="true"                                               
                class="py-1 block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
            />
            <x-input-error for="certificate" class="mt-2" />
        </div>
        <div class="grid grid-cols-2 gap-3 mt-3">
            <div>
                <x-label for="paymentType" value="Payment Type" />
                <x-simple-select
                    wire:model.lazy="paymentType"
                    :options="$paymentTypes"
                    placeholder="Select Payment Type"
                    search-input-placeholder="Select Payment Type"
                    :searchable="false"                                               
                    class="py-1 block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
                />
                <x-input-error for="paymentType" class="mt-2" />
            </div>
            <div>
                <x-label for="email" value="{{ __('questionnaire.title_6_1_email') }}" />
                <x-input id="email" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="email"/>
                <x-input-error for="email" class="mt-2" />
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3 mt-3">
            <div>
                <x-label for="first-name" value="{{ __('questionnaire.title_6_1_first_name') }}" />
                <x-input id="first-name" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="firstName"/>
                <x-input-error for="firstName" class="mt-2" />
            </div>
            <div>
                <x-label for="last-name" value="{{ __('questionnaire.title_6_1_last_name') }}" />
                <x-input id="last-name" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="lastName"/>
                <x-input-error for="lastName" class="mt-2" />
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3 mt-3">
            <div>
                <x-label for="street" value="{{ __('questionnaire.title_6_1_street') }}" />
                <x-input id="street" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="street"/>
                <x-input-error for="street" class="mt-2" />
            </div>
            <div>
                <x-label for="state" value="{{ __('questionnaire.title_6_1_state') }}" />
                <x-input id="state" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="state"/>
                <x-input-error for="state" class="mt-2" />
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3 mt-3">
            <div>
                <x-label for="city" value="{{ __('questionnaire.title_6_1_city') }}" />
                <x-input id="city" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="city"/>
                <x-input-error for="city" class="mt-2" />
            </div>
            <div>
                <x-label for="post" value="{{ __('questionnaire.title_6_1_post') }}" />
                <x-input id="post" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="post"/>
                <x-input-error for="post" class="mt-2" />
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3 mt-3">
            <div>
                <x-label for="dni" value="{{ __('questionnaire.title_6_1_dni') }}" />
                <x-input id="dni" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="dni"/>
                <x-input-error for="dni" class="mt-2" />
            </div>
            <div>
                <x-label for="phone" value="{{ __('questionnaire.title_6_1_phone') }}" />
                <x-input id="phone" class="border py-1 px-2 block mt-1 w-full" required wire:model.lazy="phone"/>
                <x-input-error for="phone" class="mt-2" />
            </div>
        </div>
    </x-slot>

    <x-slot name="buttons">
        <x-button>
            Save
        </x-button>
    </x-slot>
</x-modal>