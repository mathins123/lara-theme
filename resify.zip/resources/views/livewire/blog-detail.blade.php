<div class="bg-white">
    <div class="mx-auto md:w-4/5 lg:w-3/5 py-16">
        <h2 class="mt-2 text-xl font-bold lg:text-2xl">
            {{ $blog->title }}
        </h2>
        <div class="flex flex-row my-3">
            <div class="mr-2 text-gray-700">
                {{ $blog->user->name }}
            </div>

            <div class="w-2 h-2 my-auto mr-1 text-xl 
                    bg-gray-300 rounded-full"></div>

            <div class="my-auto text-sm text-gray-500">
                {{ $blog->published_date }}
            </div>
        </div>
        <img src="{{ asset($blog->featured_image) }}" alt="{{ $blog->title }}" 
                class="mx-auto w-auto h-auto my-4 rounded-sm max-h-96">
        <div class="prose lg:prose-xl">
            {!! $blog->body !!}
        </div>
    </div>
</div>