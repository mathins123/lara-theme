<div class="p-4 mx-auto mt-3 bg-gray-100 md:p-8 md:w-4/5 md:mt-0">
    <h1 class="mb-3 text-xl font-semibold text-gray-600">Edit Blog</h1>
    <form wire:submit.prevent="save">
        <div class="overflow-hidden bg-white rounded-md shadow">
            <div class="px-4 py-3 space-y-8 sm:p-6">
                <div>
                    <x-label for="category">
                        {{ __("Blog Category") }}
                    </x-label>
                    <x-simple-select
                        wire:model.lazy="blog.category"
                        name="blog.category"
                        id="blog.category"
                        :options="$categories"
                        placeholder="Select Category"
                        required
                        :searchable="false"
                        class="py-1 block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
                    />
                    <x-input-error for="blog.category" />
                </div>
                <div>
                    <x-label for="title">
                        {{ __("Blog Title") }}
                    </x-label>
                    <x-input class="w-full" type="text" 
                       wire:model.lazy="blog.title" id="blog.title" placeholder="Blog title" />
                    <x-input-error for="blog.title" />
                </div>
                <div class="mt-3">
                    <x-label>
                        {{ __("Excerpt") }}
                    </x-label>
                    <x-input type="text" class="w-full" id="blog.excerpt" wire:model.lazy="blog.excerpt" placeholder="Excerpt" />
                    <x-input-error for="blog.excerpt" />
                </div>
                <div class="mt-3">
                    <x-label for="photo" class="flex items-center justify-center text-3xl border-2 border-dashed rounded-sm w-full h-32 bg-gray-50">
                        {{ __('Choose image') }}
                        <x-input type="file" id="photo" accept="jpg,png,gif"
                            wire:model.lazy="photo" class="w-0 h-0"/>
                    </x-label>
                    <x-input-error for="photo" />
                </div>
                <div class="mt-3 h-2/3">
                    <x-ckeditor wire:model.lazy="blog.body" name="blog.body"/>
                </div>
                <div class="mt-3">
                    <x-label class="text-sm font-medium text-gray-700">
                        <x-input wire:model.lazy="blog.is_published" type="checkbox" 
                          class="form-checkbox" />
                        {{ __("Publish") }}
                    </x-label>
                    <x-input-error for="blog.is_published" />
                </div>
            </div>
            <div class="px-4 py-3 text-right bg-gray-50 sm:px-6">
                <x-button class="inline-flex justify-center">
                    {{ __("Save") }}
                </x-button>
            </div>
        </div>
    </form>
</div>

@push('scripts')
    <script src="/ckeditor/build/ckeditor.js"></script>
@endpush