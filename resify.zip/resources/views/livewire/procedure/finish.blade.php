
<div>
    <h2 class="text-headline my-3">
        {{__("procedure.finish_title")}}
    </h2>
    <p class="mt-5 mb-10">
        {{__("procedure.finish_content")}}
    </p>

    <p class="inline border rounded-lg text-title1 py-5 px-10">
        {{$questionnaireId}}
    </p>
</div>