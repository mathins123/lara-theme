import './bootstrap';
import 'flowbite';
import { initFlowbite } from 'flowbite';
import Alpine from 'alpinejs';
import focus from '@alpinejs/focus';
import { createPopper } from "@popperjs/core";
import Datepicker from 'flowbite-datepicker/Datepicker';

window.Alpine = Alpine;
window.Datepicker = Datepicker;

Alpine.plugin(focus);

Alpine.start();
window.createPopper = createPopper;


Livewire.hook('message.processed', (message, component) => {
    initFlowbite();
});
