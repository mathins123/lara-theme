<?php
return [
    "copy_right" => "版权所有 © 2023 Resify | 由 www.binARbox.com 开发 | 方向：Rafael Cobo Barrio | 设计：Mer | 网站管理员：Kwang, Saúl Frutos",
    "mail_to" => "info@resify.es",
    "contact" => "联系人",
    "phone" => "电话",
    "more_about" => "更多关于 Resify",
    "blog" => "博客",
    "about_us" => "关于我们",
    "faq" => "常见问题",
    "legal_terms" => "法律条款",
    "legal_warning" => "法律警告",
    "privacy_policy" => "隐私政策",
    "cookie_policy" => "Cookie 政策",
    "support" => "支持"
];