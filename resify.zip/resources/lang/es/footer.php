<?php
return [
    "copy_right" => "Copyright © 2023 Resify | Desarrollado por www.binARbox.com | Dirección: Rafael Cobo Barrio | Diseño: Mer | Webmaster: Kwang, Saúl Frutos",
    "mail_to" => "info@resify.es",
    "contact" => "Contacto",
    "phone" => "Tif",
    "more_about" => "Más sobre Resify",
    "blog" => "Blog",
    "about_us" => "Sobre nosotros",
    "faq" => "FAQs",
    "legal_terms" => "Términos legales",
    "legal_warning" => "Aviso legal",
    "privacy_policy" => "Política de privacidad",
    "cookie_policy" => "Política de cookies",
    "support" => "Support"
];