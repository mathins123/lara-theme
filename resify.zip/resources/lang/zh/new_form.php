<?php
return [
    "title" => "填写表单数据",
    "description_1" => "提交申请的代表的详细信息",
    "description_2" => "用于通知目的的地址",
    "description_detail" => "   姓名：GONZALO ASTOLFI ESPINOSA
    编号：79043367A
    西班牙地址：ALBERTO ALCOCER AVENUE
    编号：41
    楼层: S
    地点：MADRID
    邮编: 28016
    省份: MADRID
    手机：620187986
    电子邮件：Gonzalo@resify.es
    ",
    "passport" => "护照",
    "dni" => "NIE",
    "first_name" => "名字",
    "middle_name" => "第一个姓氏",
    "last_name" => "第二个姓氏",
    "gender" => "性别",
    "born_date" => "出生日期",
    "born_city" => "出生地",
    "born_country" => "出生国家",
    "nationality" => "国籍",
    "marital_status" => "婚姻状况",
    "father_name" => "父亲的名字",
    "mother_name" => "母亲的名字",
    "address_spain" => "西班牙地址",
    "street" => "街道",
    "city" => "位置",
    "post" => "邮政编码",
    "state" => "省",
    "phone" => "手机",
    "email" => "电子邮件",
    "other_name" => "姓名/公司名称",
    "other_dni" => "NIF/NIE/PASSPORT",
    "other_activity" => "活动",
    "other_occupation" => "职业",
    "other_address" => "地址",
    "other_city" => "地点",
    "other_post" => "邮政编码",
    "other_province" => "省份",
    "other_phone" => "手机",
    "other_email" => "电子邮件",
    "other_legal" => "公司或实体的法律代表",
    "other_position" => "公司职位（例如管理员）",
    "other_number" => "No",
    "other_floor" => "楼层",
    "other_passport" => "护照",
    "other_first_name" => "姓名",
    "other_middle_name" => "姓氏",
    "other_last_name" => "第二个姓氏",
    "other_relationship" => "与申请人的关系",
    "other_nationality" => "国籍"
];
