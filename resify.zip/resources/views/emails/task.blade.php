@component('mail::message')

<pre>
{!!$content!!}
</pre>

<a href="{{ $url }}" class="button button-primary" target="_blank" rel="noopener">Ir a Resify</a>

<div class="blogs">
<p>Los mejores consejos para gestionar tus tramites de extranjeria</p>    
<h1>Ir al Blog de Resify</h1>
<table style="border-spacing: 2rem; width: 100%;">    
<tbody>
<tr>
@foreach ($blogs as $blog)
<td class="blog-item">
<img src="{{ asset($blog->featured_image) }}" alt="{{ $blog->title }}">
<div class="p-3">
<h2>{{ $blog->title }}</h2>
<p>{{ $blog->excerpt }}</p>
<div>
<small style="float: left">
{{ $blog->published_date }}
</small>
<a href="{{ route('blog.detail', ['id' => $blog->id]) }}" style="float: right">
<strong>Leer mes</strong>
</a>
</div>
</div>
</td>
@endforeach
</tr>
</tbody>
</table>    
</div>

@endcomponent