<?php
return [
    "title_1" => "Discover in our blog the best tips to reside in Spain",
    "title_1_content" => "The close relationship with our clients sets us apart, especially in a process as delicate and important in people's lives as obtaining residence in another country.",
    "tab_1" => "All",
    "tab_2" => "Specialized articles",
    "tab_3" => "Immigration",
    "tab_4" => "Tips"
];
