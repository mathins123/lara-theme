<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("cookie-consent-modal")->html();
} elseif ($_instance->childHasBeenRendered('jYGrpfX')) {
    $componentId = $_instance->getRenderedChildComponentId('jYGrpfX');
    $componentTag = $_instance->getRenderedChildComponentTagName('jYGrpfX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jYGrpfX');
} else {
    $response = \Livewire\Livewire::mount("cookie-consent-modal");
    $html = $response->html();
    $_instance->logRenderedChild('jYGrpfX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<script>
    window.addEventListener('cookieChanged', event => {
        //alert('in addEventListener cookieChanged -> value: ' + event.detail.value);
        document.getElementById("cookie-board").style.display = "none";
        document.getElementById("cookie-setting").style.display = "block";
    })
</script>

<?php /**PATH D:\Work\Laravel\resify\resources\views/vendor/livewire-cookie-consent/cookieconsent.blade.php ENDPATH**/ ?>