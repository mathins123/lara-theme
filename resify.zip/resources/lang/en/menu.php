<?php
return  [
    "login" => "Log in",
    "register" => "Register",
    "about_us" => "About us",
    "our_service" => "Our Service",
    "blog" => "Blog",
    "contact" => "Contact",
    "manage_account" => "Manage Account",
    "my_profile" => "My Profile",
    "log_out" => "Log out",
    "my_procedure" => "My procedures",
    "my_profile" => "My profile",
    "payment" => "Payments and billing",
    "notification" => "Notifications",
];