<x-modal formAction="updateLanguage">
    <x-slot name="title">
        Language Details
    </x-slot>

    <x-slot name="content">
        <!-- Code -->
        <div class="px-3">
            <x-label for="editingLanguage.code" value="Code" />
            <x-input id="editingLanguage.code" class="block mt-1 w-full" type="text" wire:model.lazy="editingLanguage.code" required autocomplete="editingLanguage.code" />
            <x-input-error for="editingLanguage.code" class="mt-2" />
        </div>
        <!-- Name -->
        <div class="px-3">
            <x-label for="editingLanguage.name" value="Display Name" />
            <x-input id="editingLanguage.name" class="block mt-1 w-full" type="text" wire:model.lazy="editingLanguage.name" required autocomplete="editingLanguage.name" />
            <x-input-error for="editingLanguage.name" class="mt-2" />
        </div>
        <!-- Normal Price -->
        <div class="px-3">
            <x-label for="editingLanguage.price_normal" value="Normal Price (Cent)" />
            <x-input id="editingLanguage.price_normal" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_normal" required autocomplete="editingLanguage.price_normal" />
            <x-input-error for="editingLanguage.price_normal" class="mt-2" />
        </div>
        <!-- Normal Price Fee-->
        <div class="px-3">
            <x-label for="editingLanguage.price_normal_fee" value="Normal Price Fee (Cent)" />
            <x-input id="editingLanguage.price_normal_fee" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_normal_fee" required autocomplete="editingLanguage.price_normal_fee" />
            <x-input-error for="editingLanguage.price_normal_fee" class="mt-2" />
        </div>
        <!-- Urgent Price -->
        <div class="px-3">
            <x-label for="editingLanguage.price_urgent" value="Urgent Price (Cent)" />
            <x-input id="editingLanguage.price_urgent" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_urgent" required autocomplete="editingLanguage.price_urgent" />
            <x-input-error for="editingLanguage.price_urgent" class="mt-2" />
        </div>
        <!-- Urgent Price Fee-->
        <div class="px-3">
            <x-label for="editingLanguage.price_urgent_fee" value="Urgent Price Fee (Cent)" />
            <x-input id="editingLanguage.price_urgent_fee" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_urgent_fee" required autocomplete="editingLanguage.price_urgent_fee" />
            <x-input-error for="editingLanguage.price_urgent_fee" class="mt-2" />
        </div>
        <!-- Minimum Price -->
        <div class="px-3">
            <x-label for="editingLanguage.price_minimum" value="Minimum Price (Cent)" />
            <x-input id="editingLanguage.price_minimum" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_minimum" required autocomplete="editingLanguage.price_minimum" />
            <x-input-error for="editingLanguage.price_minimum" class="mt-2" />
        </div>
        <!-- Minimum Price Fee-->
        <div class="px-3">
            <x-label for="editingLanguage.price_minimum_fee" value="Minimum Price Fee (Cent)" />
            <x-input id="editingLanguage.price_minimum_fee" class="block mt-1 w-full" type="number" min="0" wire:model.lazy="editingLanguage.price_minimum_fee" required autocomplete="editingLanguage.price_minimum_fee" />
            <x-input-error for="editingLanguage.price_minimum_fee" class="mt-2" />
        </div>
    </x-slot>

    <x-slot name="buttons">
        <x-button>
            Save
        </x-button>
    </x-slot>
</x-modal>