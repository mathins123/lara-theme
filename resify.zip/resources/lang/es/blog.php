<?php
return [
    "title_1" => "Descubre en nuestro blog los mejores consejos para residir en España",
    "title_1_content" => "El trato cercano con nuestros clientes nos diferencia, especialmente en un proceso tan delicado e importarte en la vida de las personas como es obtener la residencia en otro país.",
    "tab_1" => "Todos",
    "tab_2" => "Artículos especializados",
    "tab_3" => "Inmigración",
    "tab_4" => "Consejos"
];
