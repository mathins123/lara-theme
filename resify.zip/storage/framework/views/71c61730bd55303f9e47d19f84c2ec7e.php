<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="px-8 md:px-12 py-8 md:py-12 bg-gray-100">
        <div class="container px-4 mx-auto">
            <div>
                <h1 class="text-title1 text-center">
                    <?php echo e(__("our_service.title_2")); ?>

                </h1>
                <h1 class="text-title1 text-center">
                    <?php echo e(__("our_service.title_2_")); ?>

                </h1>
            </div>
            <div class="flex flex-wrap -mx-4 py-8">
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/shutterstock_705449866-11.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            <?php echo e(__("dashboard.student")); ?>

                        </h3>
                        <p>
                            <?php echo __("dashboard.student_intro_1"); ?>

                        </p>
                        <p>
                            <?php echo __("dashboard.student_intro_2"); ?>

                        </p>
                        <p>
                            <?php echo __("dashboard.student_intro_3"); ?>

                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="<?php echo e(route("register.user", "student")); ?>">
                            <?php echo e(__("dashboard.student_start")); ?>

                        </a>
                    </div>
                </div>
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/shutterstock_368581874-1.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            <?php echo e(__("dashboard.individual")); ?>

                        </h3>
                        <p>
                            <?php echo __("dashboard.individual_intro_1"); ?>

                        </p>
                        <p>
                            <?php echo __("dashboard.individual_intro_2"); ?>

                        </p>
                        <p>
                            <?php echo __("dashboard.individual_intro_3"); ?>

                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="<?php echo e(route("register.user", "individual")); ?>">
                            <?php echo e(__("dashboard.individual_start")); ?>

                        </a>
                    </div>
                </div>
                <div class="w-full md:w-1/3 px-4">
                    <div class="p-8 text-center hover:bg-white rounded-md hover:shadow-xl transition duration-500">
                        <div class="w-full">
                            <img class="mx-auto" src="/image/team-meeting-online-conference-call-laptop-1.png" />
                        </div>
                        <h3 class="my-5 text-headline">
                            <?php echo e(__("dashboard.company")); ?>

                        </h3>
                        <p>
                            <?php echo __("dashboard.company_intro"); ?>

                        </p>
                        <a class="block my-5 w-full md:w-auto py-3 px-8 border border-secondary text-secondary bg-white hover:text-white hover:bg-primary rounded transition duration-500"
                            href="<?php echo e(route("register.user", "company")); ?>">
                            <?php echo e(__("dashboard.company_start")); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Work\Laravel\resify\resources\views/register_general.blade.php ENDPATH**/ ?>