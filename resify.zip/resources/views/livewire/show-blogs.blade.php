<div>
    <section class="px-8 lg:px-12 bg-gray-100">
        <div class="py-8 lg:py-16">
            <div class="container px-4 mx-auto">
                <div class="flex flex-wrap xl:items-center -mx-4">
                    <div class="w-full lg:w-2/5 px-4 lg:px-8 mb-16 lg:mb-0">
                        <h1 class="mb-6 text-title1">
                            {{ __('blog.title_1') }}
                            <img class="inline w-9 h-9" src="/image/coffie_cup.png"/>
                        </h1>
                        <p class="mb-8">
                            {{ __('blog.title_1_content') }}
                        </p>
                    </div>
                    <div class="w-full lg:w-3/5 px-4">
                        <div class="flex justify-center lg:justify-end">
                            <img src="/image/blog.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="px-8 lg:px-12 bg-white">
        <div class="py-8 lg:py-12">
            <div class="container px-4 mx-auto">
                <ul class="flex flex-wrap"
                    data-tabs-toggle="#blogTabContent" role="tablist">
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg"
                            id="all-blog-tab" data-tabs-target="#all-blog" type="button" role="tab" aria-controls="all-blog" aria-selected="true">
                            {{__("blog.tab_1")}}
                        </button>
                    </li>
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg"
                            id="special-blog-tab" data-tabs-target="#special-blog" type="button" role="tab" aria-controls="special-blog" aria-selected="false">
                            {{__("blog.tab_2")}}
                        </button>
                    </li>
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg"
                            id="immigration-blog-tab" data-tabs-target="#immigration-blog" type="button" role="tab" aria-controls="immigration-blog" aria-selected="false">
                            {{__("blog.tab_3")}}
                        </button>
                    </li>
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg"
                            id="tip-blog-tab" data-tabs-target="#tip-blog" type="button" role="tab" aria-controls="tip-blog" aria-selected="false">
                            {{__("blog.tab_4")}}
                        </button>
                    </li>
                </ul>

                <div id="blogTabContent">
                    <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800"
                        id="all-blog" role="tabpanel" aria-labelledby="all-blog-tab">
                        <div class="gap-8 mt-8 md:grid md:grid-cols-2 lg:grid-cols-3">
                            @foreach ($blogs as $blog)
                                @livewire('blog-item', ['blog' => $blog], key($blog->id))
                            @endforeach
                        </div>
                    </div>
                    <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800"
                        id="special-blog" role="tabpanel" aria-labelledby="special-blog-tab">
                        <div class="gap-8 mt-8 md:grid md:grid-cols-2 lg:grid-cols-3">
                            @foreach ($blogs as $blog)
                                @if($blog->category == "special")
                                    @livewire('blog-item', ['blog' => $blog], key($blog->id))
                                @endif
                            @endforeach
                        </div>
                    </div>
                    <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800"
                        id="immigration-blog" role="tabpanel" aria-labelledby="immigration-blog-tab">
                        <div class="gap-8 mt-8 md:grid md:grid-cols-2 lg:grid-cols-3">
                            @foreach ($blogs as $blog)
                                @if($blog->category == "immigration")
                                    @livewire('blog-item', ['blog' => $blog], key($blog->id))
                                @endif
                            @endforeach
                        </div>
                    </div>
                    <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800"
                        id="tip-blog" role="tabpanel" aria-labelledby="tip-blog-tab">
                        <div class="gap-8 mt-8 md:grid md:grid-cols-2 lg:grid-cols-3">
                            @foreach ($blogs as $blog)
                                @if($blog->category == "tip")
                                    @livewire('blog-item', ['blog' => $blog], key($blog->id))
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
