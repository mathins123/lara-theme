<?php echo e($slot); ?>

<?php /**PATH D:\Work\Laravel\resify\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>