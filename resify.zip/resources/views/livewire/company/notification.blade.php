<div>
    <div class="mt-5">
        <h1 class="text-headline">
            {{__("employee.employee_list")}}
        </h1>
        
        <table class="w-full mt-5 text-sm text-left text-gray-500 dark:text-gray-400" x-data="">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        {{__('Name')}}
                    </th>
                    <th scope="col" class="px-6 py-3">
                        {{__('Email')}}
                    </th>
                    <th scope="col" class="px-6 py-3">
                        {{__('Phone')}}
                    </th>
                </tr>
            </thead>
            <tbody>
                @if(empty($employees) || count($employees) < 1)
                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <th scope="row" colspan="3" class="text-center px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            No Data
                        </th>
                    </tr>            
                @else
                    @foreach ($employees as $item)
                        <tr x-data class="cursor-pointer bg-white hover:bg-gray-50 border-b dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-600"
                            @click="window.location.href='{{route('notification', $item->id)}}'">
                            <th scope="row" class="px-6 py-4 font-medium whitespace-nowrap">
                                {{$item->name}}
                            </th>
                            <td class="px-6 py-4">
                                {{$item->email}}
                            </td>
                            <td class="px-6 py-4">
                                {{$item->phone}}
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
</div>
