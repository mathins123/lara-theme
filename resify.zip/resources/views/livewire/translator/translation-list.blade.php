<div class="pb-16">
    <header class="bg-white shadow">
        <div class="py-6 px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between">
                <h1 class="align-middle text-2xl text-primary">{{__("translation.my_translation")}}</h1>
            </div>
        </div>
    </header>

    <div class="bg-white dark:bg-gray-800 sm:px-6 lg:px-8 p-5 overflow-hidden shadow-sm sm:rounded-lg">
        <div class="relative overflow-x-auto border mt-5">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400" x-data="">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            {{__('Original Document')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Language')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Word Count')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Price')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Vat')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Customer')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Accepted')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Result')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Completed')}}
                        </th>
                        <th scope="col" class="px-6 py-3">
                            {{__('Action')}}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @if(empty($translations) || count($translations) < 1)
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <th scope="row"colspan="9" class="text-center px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                No Data
                            </th>
                        </tr>            
                    @else
                        @foreach ($translations as $item)
                            <tr x-data class="cursor-pointer bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                {{-- @click="window.location.href='{{route('admin.procedure', $item->id)}}'"> --}}
                                <th scope="row" class="px-6 py-4 font-medium whitespace-nowrap">
                                    <a class="hover:text-blue-500 underline" target="_blank" href="https://docs.resify.es/{{$item->org_path}}">{{$item->title}}</a>
                                </th>
                                <td class="px-6 py-4">
                                    {{$item->language->name}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$item->count}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$item->price}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$item->price * 0.21}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$item->customer->name}}
                                </td>
                                <td class="px-6 py-4">
                                    @if($item->accepted)
                                        @if($item->completed)
                                            <span>Accepted</span>
                                        @else
                                            <button
                                                class="py-3 px-7 text-center text-white hover:text-danger bg-danger hover:bg-white border border-danger rounded-md shadow-sm"
                                                wire:click="rejectTranslation({{$item->id}})"
                                            >
                                                Reject
                                            </button>
                                        @endif
                                    @else
                                        <button
                                            class="py-3 px-7 text-center text-white hover:text-primary bg-primary hover:bg-white border border-primary rounded-md shadow-sm"
                                            wire:click="acceptTranslation({{$item->id}})"
                                        >
                                            Accept
                                        </button>
                                    @endif
                                </td>
                                <th scope="row" class="px-6 py-4 font-medium whitespace-nowrap">
                                    @if(!empty($item->result_path))
                                        <a class="hover:text-blue-500 underline" target="_blank" href="/{{$item->result_path}}">{{$item->getResultName()}}</a>
                                    @endif
                                </th>
                                <td class="px-6 py-4">
                                    @if($item->completed)
                                        <span>Completed</span>
                                    @elseif($item->accepted)
                                        <span>Translating...</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4" wire:click.stop="">
                                    {{-- @if(!$item->accepted)
                                        <i class="fa fa-edit hover:text-blue-500" wire:click.stop="$emit('openModal', 'edit-translation', {{ json_encode(['id' => $item->id]) }})"></i>
                                    @endif --}}
                                    @if ($item->accepted && !$item->completed)
                                        <i class="fa fa-edit hover:text-blue-500" wire:click.stop="$emit('openModal', 'translator.edit-translation', {{ json_encode(['id' => $item->id]) }})"></i>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>

        <div class="my-3">
            {{ $translations->links() }}
        </div>
    </div>

</div>