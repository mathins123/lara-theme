<?php
return [
    "title_1" => "Login to your Resify account",
    "title_2" => "How are you!",
    "form_email" => "Email",
    "form_password" => "Password",
    "form_remember" => "Remember user",
    "form_forgot" => "Forgot your password?",
    "form_submit" => "Login"
];
