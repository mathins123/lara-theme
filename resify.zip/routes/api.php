<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Mail;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/mail/share_item', function(Request $request) {
    $fromName = $request->fromname;
    $fromEmail = $request->fromemail;
    $toName = $request->toname;
    $toEmail = $request->toemail;
    $title = "$fromEmail shared their card";
    $content = $request->message;
    $link = $request->permalink;

    $to = [
        'email' => $toEmail, 
        'name' => $toName,
    ];
    Mail::to($toEmail)->send(new \App\Mail\ShareItem($title, $content, $link, $fromName, $fromEmail));

    return ["success"=> true];
});
